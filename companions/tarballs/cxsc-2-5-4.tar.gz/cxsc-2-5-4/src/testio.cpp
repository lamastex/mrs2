/*
**  CXSC is a C++ library for eXtended Scientific Computing (V 2.5.4)
**
**  Copyright (C) 1990-2000 Institut fuer Angewandte Mathematik,
**                          Universitaet Karlsruhe, Germany
**            (C) 2000-2014 Wiss. Rechnen/Softwaretechnologie
**                          Universitaet Wuppertal, Germany   
**
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Library General Public
**  License as published by the Free Software Foundation; either
**  version 2 of the License, or (at your option) any later version.
**
**  This library is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
**  Library General Public License for more details.
**
**  You should have received a copy of the GNU Library General Public
**  License along with this library; if not, write to the Free
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/* CVS $Id: testio.cpp,v 1.23 2014/01/30 17:23:49 cxsc Exp $ */

#include <iostream>
#include "real.hpp"
#include "ioflags.hpp"

namespace cxsc {

int main(void)
{
   real a;
   "3.1415926535897932384626433832795028841971693993" >> a;
   cout << SetPrecision(19,11);
   cout << "a: >" << a << "<" << endl;
   
   "1024" >> a;
   cout << "a: >" << a << "<" << endl;
   
   "-1024" >> a;
   cout << "a: >" << a << "<" << endl;
   
   a=123.456e+78;
   cout << "a: >" << a << "<" << endl;
   
   a=-123.456e-78;
   cout << "a: >" << a << "<" << endl;

   a=0;
   cout << "a: >" << a << "<" << endl;
   return 0;
}

} // namespace cxsc

