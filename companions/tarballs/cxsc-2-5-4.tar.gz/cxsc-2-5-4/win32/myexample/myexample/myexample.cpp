// Author: Boris Hoeffgen <hoeffgen@uni-wuppertal.de>
//		   Dr. Werner Hofschuster <hofschuster@math.uni-wuppertal.de>
#include "myexample.h"

int main(void){
	interval a,b;

	a=1.0;
	b=3.0;

	cout << "a/b = " << a/b << endl;

	return 0;
}