/*
 *  Created on: 2009-09-02
 *      Author: iikapela
 */
#ifndef _UNITTESTS_RECT2SETTEST_CPP_
#define _UNITTESTS_RECT2SETTEST_CPP_

#include "capd/capdlib.h"

typedef capd::C0Rect2Set SetType;

#define FIXTURE_NAME Rect2SetTest

#include "AffineSetCommonTest.hpp"
#include "CenteredDoubletonSpecific.hpp"


#endif
