/*
 *  Created on: 2009-09-02
 *      Author: iikapela
 */
#ifndef _UNITTESTS_RECTSETTEST_CPP_
#define _UNITTESTS_RECTSETTEST_CPP_

#include "capd/capdlib.h"

typedef capd::C0RectSet SetType;

#define FIXTURE_NAME RectSetTest
#include "AffineSetCommonTest.hpp"
#include "CenteredAffineSetSpecific.hpp"

#endif
