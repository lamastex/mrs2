
#define BOOST_TEST_MODULE mapTest
#define BOOST_TEST_DYN_LINK

#include <boost/test/unit_test.hpp>
 