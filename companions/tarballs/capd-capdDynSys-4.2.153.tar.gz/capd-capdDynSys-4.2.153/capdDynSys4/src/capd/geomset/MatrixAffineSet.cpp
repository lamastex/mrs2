#include "capd/vectalg/lib.h"
#include "capd/geomset/MatrixAffineSet.hpp"
#include "capd/vectalg/iobject.hpp"

template class capd::geomset::MatrixAffineSet< capd::IMatrix >;
